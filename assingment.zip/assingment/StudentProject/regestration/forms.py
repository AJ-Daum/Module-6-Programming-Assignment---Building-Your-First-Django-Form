

from django import forms


MAJOR_CHOICES = [
    ('CS', 'Computer Science'),
    ('EE', 'Electrical Engineering'),
    ('ME', 'Mechanical Engineering'),
    ('CE', 'Civil Engineering'),
    ('BIO', 'Biology'),
]

CLASS_STANDING = [
    ('freshman', 'Freshman'),
    ('sophomore', 'Sophomore'),
    ('junior', 'Junior'),
    ('senior', 'Senior'),
]

PROG_LANGS = [
    ('python', 'Python'),
    ('java', 'Java'),
    ('c++', 'C++'),
    ('javascript', 'JavaScript'),
    ('ruby', 'Ruby'),
]


class RegistrationForm(forms.Form):
    student_name = forms.CharField(max_length=100)
    student_id = forms.CharField(max_length=10)
    major = forms.ChoiceField(choices=MAJOR_CHOICES, widget=forms.Select())
    class_standing = forms.ChoiceField(
        choices=CLASS_STANDING, widget=forms.RadioSelect()
        )
    prog_langs = forms.MultipleChoiceField(
        choices=PROG_LANGS, 
        widget=forms.CheckboxSelectMultiple()
        )
    graduation_year = forms.IntegerField(widget=forms.NumberInput())
    comments = forms.CharField(max_length=2000, widget=forms.Textarea())










