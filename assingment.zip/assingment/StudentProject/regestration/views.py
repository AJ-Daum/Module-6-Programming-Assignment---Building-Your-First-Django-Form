from django.shortcuts import render
from .forms import RegistrationForm, MAJOR_CHOICES, CLASS_STANDING, PROG_LANGS




# Create your views here.

def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            student_name = form.cleaned_data['student_name']
            student_id = form.cleaned_data['student_id']
            major_dict = dict(MAJOR_CHOICES)
            prog_dict = dict(PROG_LANGS)
            class_standing_dict = dict(CLASS_STANDING)
            major = major_dict.get(form.cleaned_data['major'])
            class_standing = class_standing_dict.get(form.cleaned_data['class_standing'])
            prog_langs = prog_dict[form.cleaned_data['prog_langs']]
            graduation_year = form.cleaned_data['graduation_year']
            comments = form.cleaned_data['comments']
            return render(request, 'results.html', {
                'student_name': student_name,
                'student_id': student_id,
                'major': major,
                'class_standing': class_standing,
                'prog_langs': prog_langs,
                'graduation_year': graduation_year,
                'comments': comments
            })
    else:
        form = RegistrationForm()
    return render(request, 'register.html', {'form': form})






